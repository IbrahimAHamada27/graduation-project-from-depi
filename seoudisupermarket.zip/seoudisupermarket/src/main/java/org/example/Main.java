package org.example;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class Main {

    public static void main(String[] args) throws InterruptedException {

        // ===================================================
        // FIRST FULL LOGIN + LOGOUT
        // ===================================================
        WebDriver driver = new FirefoxDriver();
        driver.manage().window().maximize();
        driver.get("https://seoudisupermarket.com/");
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));

        // Popup
        wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("button[aria-label='close']"))).click();

        // City
        wait.until(ExpectedConditions.elementToBeClickable(By.id("city"))).click();
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//option[contains(text(),'Cairo')]"))).click();

        // Area
        wait.until(ExpectedConditions.elementToBeClickable(By.id("area"))).click();
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//select[@id='area']/option[2]"))).click();

        // District
        wait.until(ExpectedConditions.elementToBeClickable(By.id("district"))).click();
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//select[@id='district']/option[2]"))).click();

        // Continue
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'Continue to shop')]"))).click();

        // Account
        wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("a[href='/en/account']"))).click();
        wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("a[href='/en/login']"))).click();

        // Login
        wait.until(ExpectedConditions.elementToBeClickable(By.id("phone"))).sendKeys("01112540997");
        wait.until(ExpectedConditions.elementToBeClickable(By.id("password"))).sendKeys("Ibrahim@2006");
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'Login to your account')]"))).click();

        Thread.sleep(5000);

        // Logout
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'Ibrahim')]"))).click();
        Thread.sleep(2000);
        wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("button.LogoutBtn"))).click();

        Thread.sleep(2000);


        // ===================================================
        // ATTEMPT 1 — WRONG PASSWORD
        // ===================================================
        wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("button[aria-label='close']"))).click();
        wait.until(ExpectedConditions.elementToBeClickable(By.id("city"))).click();
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//option[contains(text(),'Cairo')]"))).click();
        wait.until(ExpectedConditions.elementToBeClickable(By.id("area"))).click();
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//select[@id='area']/option[2]"))).click();
        wait.until(ExpectedConditions.elementToBeClickable(By.id("district"))).click();
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//select[@id='district']/option[2]"))).click();
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'Continue to shop')]"))).click();
        wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("a[href='/en/account']"))).click();
        wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("a[href='/en/login']"))).click();

        WebElement phoneFieldAttempt1 = wait.until(ExpectedConditions.elementToBeClickable(By.id("phone")));
        phoneFieldAttempt1.clear();
        phoneFieldAttempt1.sendKeys("01112540997");

        WebElement passwordFieldAttempt1 = wait.until(ExpectedConditions.elementToBeClickable(By.id("password")));
        passwordFieldAttempt1.clear();
        passwordFieldAttempt1.sendKeys("WrongPass123");

        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'Login to your account')]"))).click();
        Thread.sleep(2000);

        driver.quit();


        // ===================================================
        // ATTEMPT 2 — WRONG PHONE
        // ===================================================
        WebDriver driver3 = new FirefoxDriver();
        driver3.manage().window().maximize();
        driver3.get("https://seoudisupermarket.com/");
        WebDriverWait wait3 = new WebDriverWait(driver3, Duration.ofSeconds(5));

        repeatNavigation(wait3);

        WebElement phoneFieldAttempt2 = wait3.until(ExpectedConditions.elementToBeClickable(By.id("phone")));
        phoneFieldAttempt2.sendKeys("01000000000"); // wrong phone

        WebElement passAttempt2 = wait3.until(ExpectedConditions.elementToBeClickable(By.id("password")));
        passAttempt2.sendKeys("Ibrahim@2006");

        wait3.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'Login to your account')]"))).click();
        Thread.sleep(2000);

        driver3.quit();


        // ===================================================
        // ATTEMPT 3 — EMPTY PASSWORD
        // ===================================================
        WebDriver driver4 = new FirefoxDriver();
        driver4.manage().window().maximize();
        driver4.get("https://seoudisupermarket.com/");
        WebDriverWait wait4 = new WebDriverWait(driver4, Duration.ofSeconds(5));

        repeatNavigation(wait4);

        wait4.until(ExpectedConditions.elementToBeClickable(By.id("phone"))).sendKeys("01112540997");
        wait4.until(ExpectedConditions.elementToBeClickable(By.id("password"))).sendKeys("");

        wait4.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'Login to your account')]"))).click();

        Thread.sleep(2000);
        driver4.quit();


        // ===================================================
        // ATTEMPT 4 — EMPTY PHONE
        // ===================================================
        WebDriver driver5 = new FirefoxDriver();
        driver5.manage().window().maximize();
        driver5.get("https://seoudisupermarket.com/");
        WebDriverWait wait5 = new WebDriverWait(driver5, Duration.ofSeconds(5));

        repeatNavigation(wait5);

        wait5.until(ExpectedConditions.elementToBeClickable(By.id("phone"))).sendKeys("");
        wait5.until(ExpectedConditions.elementToBeClickable(By.id("password"))).sendKeys("Ibrahim@2006");

        wait5.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'Login to your account')]"))).click();

        Thread.sleep(2000);
        driver5.quit();
    }


    // ===================================================
    // REPEATED NAVIGATION FUNCTION (Your Logic Kept)
    // ===================================================

    public static void repeatNavigation(WebDriverWait wait) {

        wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("button[aria-label='close']"))).click();
        wait.until(ExpectedConditions.elementToBeClickable(By.id("city"))).click();
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//option[contains(text(),'Cairo')]"))).click();
        wait.until(ExpectedConditions.elementToBeClickable(By.id("area"))).click();
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//select[@id='area']/option[2]"))).click();
        wait.until(ExpectedConditions.elementToBeClickable(By.id("district"))).click();
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//select[@id='district']/option[2]"))).click();
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'Continue to shop')]"))).click();
        wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("a[href='/en/account']"))).click();
        wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("a[href='/en/login']"))).click();
    }

}
