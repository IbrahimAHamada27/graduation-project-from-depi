Feature: Login attempts for Seoudi Supermarket

Scenario Outline: Login attempts using multiple credentials
Given user opens the website
And user closes popup if exists
And user selects location
And user navigates to login page
When user enters phone "<phone>"
And user enters password "<password>"
And user clicks login button
Then login attempt should complete

Examples:
        | phone         | password      |
        | 01112540997   | Ibrahim@2006  |
        | 01112540997   | WrongPass123  |
        | 01000000000   | Ibrahim@2006  |
        | 01112540997   |               |
        |               | Ibrahim@2006  |
