package pages;

import core.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class AccountPage extends BasePage {

    By accountBtn = By.cssSelector("a[href='/en/account']");
    By loginBtn = By.cssSelector("a[href='/en/login']");
    By accountName = By.xpath("//span[contains(text(),'Ibrahim')]");

    public AccountPage(WebDriver driver) {
        super(driver);
    }

    public void openLoginPage() {
        driver.findElement(accountBtn).click();
        driver.findElement(loginBtn).click();
    }

    public boolean isLoggedIn() {
        try {
            return driver.findElement(accountName).isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }
}
