package pages;

import core.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class AccountPage extends BasePage {

    public AccountPage(WebDriver driver) {
        super(driver);
    }

    public void openLoginPage(){
        wait.until(ExpectedConditions.elementToBeClickable(
                By.cssSelector("a[href='/en/account']"))).click();

        wait.until(ExpectedConditions.elementToBeClickable(
                By.cssSelector("a[href='/en/login']"))).click();
    }
}
