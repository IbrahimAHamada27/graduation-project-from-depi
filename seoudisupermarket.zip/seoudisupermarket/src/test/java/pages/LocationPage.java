package pages;

import core.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class LocationPage extends BasePage {

    public LocationPage(WebDriver driver) {
        super(driver);
    }

    public void selectLocation(){

        wait.until(ExpectedConditions.elementToBeClickable(By.id("city"))).click();
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//option[contains(text(),'Cairo')]"))).click();

        wait.until(ExpectedConditions.elementToBeClickable(By.id("area"))).click();
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//select[@id='area']/option[2]"))).click();

        wait.until(ExpectedConditions.elementToBeClickable(By.id("district"))).click();
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//select[@id='district']/option[2]"))).click();

        wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//button[contains(text(),'Continue to shop')]"))).click();
    }
}
