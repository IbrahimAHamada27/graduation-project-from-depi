package pages;

import core.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LocationPage extends BasePage {

    By city = By.id("city");
    By cairo = By.xpath("//option[contains(text(),'Cairo')]");
    By area = By.id("area");
    By areaOption = By.xpath("//select[@id='area']/option[2]");
    By district = By.id("district");
    By districtOption = By.xpath("//select[@id='district']/option[2]");
    By continueBtn = By.xpath("//button[contains(text(),'Continue to shop')]");

    public LocationPage(WebDriver driver) {
        super(driver);
    }

    public void selectLocation() {
        driver.findElement(city).click();
        driver.findElement(cairo).click();
        driver.findElement(area).click();
        driver.findElement(areaOption).click();
        driver.findElement(district).click();
        driver.findElement(districtOption).click();
        driver.findElement(continueBtn).click();
    }
}
