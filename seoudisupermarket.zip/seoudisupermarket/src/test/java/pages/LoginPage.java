package pages;

import core.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage extends BasePage {

    By phoneField = By.id("phone");
    By passwordField = By.id("password");
    By loginButton = By.xpath("//span[contains(text(),'Login to your account')]");

    By requiredMessage = By.xpath("//span[text()='This field is required']");
    By invalidMessage = By.xpath("//span[contains(text(),'Invalid')]");

    public LoginPage(WebDriver driver) {
        super(driver);
    }

    public void enterPhone(String phone){
        driver.findElement(phoneField).clear();
        driver.findElement(phoneField).sendKeys(phone);
    }

    public void enterPassword(String pass){
        driver.findElement(passwordField).clear();
        driver.findElement(passwordField).sendKeys(pass);
    }

    public void clickLogin(){
        driver.findElement(loginButton).click();
    }

    public void failedLogin(String phone, String password){
        enterPhone(phone);
        enterPassword(password);
        clickLogin();
    }

    public boolean isRequiredMessageDisplayed() {
        try {
            return driver.findElement(requiredMessage).isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    public boolean isInvalidCredentialsDisplayed() {
        try {
            return driver.findElement(invalidMessage).isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }
}
