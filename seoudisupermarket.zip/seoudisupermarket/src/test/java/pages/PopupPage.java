package pages;

import core.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class PopupPage extends BasePage {

    public PopupPage(WebDriver driver) {
        super(driver);
    }

    public void closePopup(){
        wait.until(ExpectedConditions.elementToBeClickable(
                By.cssSelector("button[aria-label='close']"))).click();
    }
}
