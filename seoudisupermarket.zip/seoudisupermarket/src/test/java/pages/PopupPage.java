package pages;

import core.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class PopupPage extends BasePage {

    By closePopupBtn = By.cssSelector("button[aria-label='close']");

    public PopupPage(WebDriver driver) {
        super(driver);
    }

    public void closePopup() {
        try {
            driver.findElement(closePopupBtn).click();
        } catch (Exception e) {
            System.out.println("No popup displayed.");
        }
    }
}
