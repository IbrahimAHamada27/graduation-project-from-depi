package stepdefinitions;

import hooks.Hooks;
import io.cucumber.java.en.*;
import org.openqa.selenium.WebDriver;
import pages.*;


public class LoginSteps {

    WebDriver driver = Hooks.driver;

    PopupPage popup;
    LocationPage location;
    AccountPage account;
    LoginPage login;

    @Given("user opens the website")
    public void user_opens_website() {
        driver.get("https://seoudisupermarket.com/");
        popup = new PopupPage(driver);
        location = new LocationPage(driver);
        account = new AccountPage(driver);
        login = new LoginPage(driver);
    }

    @And("user closes popup if exists")
    public void closes_popup() {
        popup.closePopup();
    }

    @And("user selects location")
    public void user_selects_location() {
        location.selectLocation();
    }

    @And("user navigates to login page")
    public void user_navigates_login() {
        account.openLoginPage();
    }

    @When("user enters phone {string}")
    public void enters_phone(String phone) {
        login.enterPhone(phone);
    }

    @When("user enters password {string}")
    public void enters_password(String password) {
        login.enterPassword(password);
    }

    @And("user clicks login button")
    public void click_login_button() {
        login.clickLogin();
    }

    @Then("login attempt should complete")
    public void login_attempt_done() {
        System.out.println("Login Attempt Completed!");
    }
}
