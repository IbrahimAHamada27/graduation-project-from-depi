package stepdefinitions;

import hooks.Hooks;
import io.cucumber.java.en.*;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import pages.*;

public class LoginSteps {

    WebDriver driver = Hooks.driver;

    PopupPage popup;
    LocationPage location;
    AccountPage account;
    LoginPage login;

    // ============================
    // GIVEN STEPS
    // ============================

    @Given("user opens the website")
    public void user_opens_website() {
        driver.get("https://seoudisupermarket.com/");
        popup = new PopupPage(driver);
        location = new LocationPage(driver);
        account = new AccountPage(driver);
        login = new LoginPage(driver);
    }

    @And("user closes popup if exists")
    public void closes_popup() {
        popup.closePopup();
    }

    @And("user selects location")
    public void user_selects_location() {
        location.selectLocation();
    }

    @And("user navigates to login page")
    public void user_navigates_login() {
        account.openLoginPage();
    }

    // ============================
    // WHEN STEPS
    // ============================

    @When("user enters phone {string}")
    public void enters_phone(String phone) {
        login.enterPhone(phone);
    }

    @When("user enters password {string}")
    public void enters_password(String password) {
        login.enterPassword(password);
    }

    @And("user clicks login button")
    public void click_login_button() {
        login.clickLogin();
    }

    // ============================
    // FINAL VALIDATION STEP
    // ============================

    @Then("login attempt should be processed")
    public void login_attempt_should_be_processed() {

        boolean loggedIn = account.isLoggedIn();                     // رسالة الدخول الصح
        boolean requiredErr = login.isRequiredMessageDisplayed();    // This field is required
        boolean invalidErr = login.isInvalidCredentialsDisplayed();  // Invalid phone or password

        // ============================
        // LOGIN LOGIC
        // ============================

        // 1) بيانات صح → لازم رسالة الدخول تظهر
        if (loggedIn) {
            Assert.assertTrue(
                    !requiredErr && !invalidErr,
                    "❌ Valid login but error message appeared!"
            );
            System.out.println("✔ VALID login → PASS");
            return;
        }

        // 2) بيانات غلط + مفيش رسالة دخول + مفيش Errors → PASS
        if (!loggedIn && !requiredErr && !invalidErr) {
            System.out.println("✔ INVALID login with NO success message → PASS");
            return;
        }

        // 3) بيانات غلط + Error Message ظاهر → PASS
        if (!loggedIn && (requiredErr || invalidErr)) {
            System.out.println("✔ INVALID login with error message → PASS");
            return;
        }

        // 4) بيانات غلط + ظهر Login Success → FAIL
        Assert.fail("❌ Invalid login BUT login-success message appeared!");
    }
}
