package tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.*;
import pages.*;

public class LoginTests {

    WebDriver driver;
    PopupPage popup;
    LocationPage location;
    AccountPage account;
    LoginPage login;

    @BeforeMethod
    public void setup(){
        driver = new FirefoxDriver();
        driver.manage().window().maximize();
        popup = new PopupPage(driver);
        location = new LocationPage(driver);
        account = new AccountPage(driver);
        login = new LoginPage(driver);
    }

    public void navigateToLogin(){
        driver.get("https://seoudisupermarket.com/");
        popup.closePopup();
        location.selectLocation();
        account.openLoginPage();
    }

    @Test
    public void validLogin(){

        navigateToLogin();
        login.enterPhone("01112540997");
        login.enterPassword("Ibrahim@2006");
        login.clickLogin();
    }

    @Test
    public void wrongPassword(){
        navigateToLogin();
        login.failedLogin("01112540997","WrongPass123");
    }

    @Test
    public void wrongPhone(){
        navigateToLogin();
        login.failedLogin("01000000000","Ibrahim@2006");
    }

    @Test
    public void emptyPassword(){
        navigateToLogin();
        login.failedLogin("01112540997","");
    }

    @Test
    public void emptyPhone(){
        navigateToLogin();
        login.failedLogin("","Ibrahim@2006");
    }

    @AfterMethod
    public void tearDown(){
        driver.quit();
    }
}
