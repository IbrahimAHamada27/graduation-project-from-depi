package tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.*;
import pages.*;

import java.time.Duration;

public class LoginTests {

    WebDriver driver;
    PopupPage popup;
    LocationPage location;
    AccountPage account;
    LoginPage login;

    @BeforeMethod
    public void setup(){
        driver = new FirefoxDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

        popup = new PopupPage(driver);
        location = new LocationPage(driver);
        account = new AccountPage(driver);
        login = new LoginPage(driver);
    }

    public void navigateToLogin(){
        driver.get("https://seoudisupermarket.com/");
        popup.closePopup();
        location.selectLocation();
        account.openLoginPage();
    }

    // ===================================
    // VALID LOGIN
    // ===================================
    @Test
    public void validLogin(){
        navigateToLogin();
        login.failedLogin("01112540997","Ibrahim@2006");

        boolean ok = account.isLoggedIn();
        boolean reqErr = login.isRequiredMessageDisplayed();
        boolean invalidErr = login.isInvalidCredentialsDisplayed();

        Assert.assertTrue(
                ok && !reqErr && !invalidErr,
                "Valid Login MUST succeed.\n" +
                        "loggedIn=" + ok +
                        ", requiredMsg=" + reqErr +
                        ", invalidMsg=" + invalidErr
        );
    }

    // ===================================
    // NEGATIVE TESTS
    // ===================================
    @Test
    public void wrongPassword(){
        navigateToLogin();
        login.failedLogin("01112540997","WrongPass123");

        boolean ok = account.isLoggedIn();

        Assert.assertTrue(
                !ok,
                "Expected login to FAIL for wrong password.\n" +
                        "But user LOGGED IN = " + ok
        );
    }

    @Test
    public void wrongPhone(){
        navigateToLogin();
        login.failedLogin("01000000000","Ibrahim@2006");

        boolean ok = account.isLoggedIn();

        Assert.assertTrue(
                !ok,
                "Expected login to FAIL for wrong phone.\n" +
                        "But user LOGGED IN = " + ok
        );
    }

    @Test
    public void emptyPassword(){
        navigateToLogin();
        login.failedLogin("01112540997","");

        boolean ok = account.isLoggedIn();

        Assert.assertTrue(
                !ok,
                "Empty password should NOT allow login.\n" +
                        "But user LOGGED IN = " + ok
        );
    }

    @Test
    public void emptyPhone(){
        navigateToLogin();
        login.failedLogin("","Ibrahim@2006");

        boolean ok = account.isLoggedIn();

        Assert.assertTrue(
                !ok,
                "Empty phone should NOT allow login.\n" +
                        "But user LOGGED IN = " + ok
        );
    }



    @AfterMethod
    public void tearDown(){
        if(driver != null){
            driver.quit();
        }
    }
}
